import Alamofire
import Foundation
import SwiftSoup
import SwiftyTextTable

let group = DispatchGroup()

func main() {
    group.enter()
    let args = CommandLine.arguments[1]
    let keyword = args.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
    Alamofire.request("https://torrentwal.com/bbs/s.php?k=" + keyword).responseString { response in
    if let html = response.result.value {
        let titles = get_titles(html)
        let magnets = get_magnets(html)

        let title = TextTableColumn(header: "title")
        let magnet = TextTableColumn(header: "magnet")
        var table = TextTable(columns: [title, magnet])

        for idx in 0..<titles.count {
            table.addRow(values: [titles[idx], magnets[idx]])
        }
        let tableString = table.render()
        print(tableString)
    }
    group.leave()
    }
}

func get_titles(_ html: String) -> [String] {
    var titles = [String]()
    do {
        let elements: Elements = try SwiftSoup.parse(html).getElementsByAttribute("target")
        for link: Element in elements.array() {
            let linkText: String = try link.text()
            titles.append(linkText)
        }
    } catch Exception.Error(_, let message) {
        print(message)
    } catch {
            print("error")
    }
    return titles
}

func get_magnets(_ html: String) -> [String] {
    var magnets = [String]()
    do {
        let elements: Elements = try SwiftSoup.parse(html).select("a")
        for link: Element in elements.array() {
            let linkHref: String = try link.attr("href")
            if linkHref.contains("javascript:Mag_dn") {
                let lowerBound = String.Index(encodedOffset: 19)
                let upperBound = String.Index(encodedOffset: 59)
                let mySubstring = linkHref[lowerBound..<upperBound]
                let magnet = "magnet:?xt=urn:btih:" + mySubstring
                magnets.append(magnet)
            }
        }
    } catch Exception.Error(_, let message) {
            print(message)
    } catch {
            print("error")
    }
    return magnets
}

main()
group.notify(queue: DispatchQueue.main) {
    exit(0)
}
dispatchMain()
