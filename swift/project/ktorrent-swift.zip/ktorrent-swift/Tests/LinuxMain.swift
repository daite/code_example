import XCTest

import ktorrent_swiftTests

var tests = [XCTestCaseEntry]()
tests += ktorrent_swiftTests.allTests()
XCTMain(tests)
