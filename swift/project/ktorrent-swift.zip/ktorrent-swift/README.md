# ktorrent-swift

It sucks!
![torrentwal](https://i.imgur.com/CdioxOG.png)
