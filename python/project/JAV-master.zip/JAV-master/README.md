# JAVImageDownloader (SIRO, GANA200)

**usage: jav_image_download.py [-h] [-g] [-s] start end**
* siro example -> jav_image_download.py -s 1011 1022
* gana example -> jav_image_download.py -g 560 580

# ScreenShot 
![alt tag](https://github.com/daite/JAV-Image-parser/blob/master/test_image/sample.png)
![alt tag](https://github.com/daite/JAV-Image-parser/blob/master/test_image/sample2.png)

# jav.py
![alt tag](https://raw.githubusercontent.com/daite/JAV/master/test_image/jav.png)

# Description Example
二人っきりでホテルに行ったらやる事は一つ。さぁ！はじまりましたぁ〜ｗそれにしても今日は天気がいいなぁ〜！今日はいい女と出会える気がする。街を歩いているといましたｗいましたぁ〜！黒髪ショートでスタイルもとても良くてちょい天然さんな女の子。お肌もツヤツヤで色も白いのだ。たまらんねぇ〜ｗおじさんには彼女が輝いて見えるよ！早速ホテルに移動し下着チェックとまいりましょう。谷間が凄い・・なんて谷間をしているんだろう。今からでも良い。俺を挟んでくれ！真剣白刃取りが出来そうなくらいの深い谷間さんｗ彼女が笑う度に胸がぷるぷる揺れるのだ。

スカート上げるとドエロイTバックでお尻もぷるんぷるんしてるｗボン・キュ・ボ〜ンのええ身体。ブラをめくると、程よい大きさの乳首が顔を出す。「こんにちわ」乳首を触り舐めまくるとおっきし放題。2つのチョモランマが俺を見ている。もう我慢できないよｗキスをしながらま◯こを触る。すると乳首もさらに立ち誇る。生唾が止まらない。パンティーを脱がし、直にいじる。指先でヒダの部分を触るだけで彼女は感じ始める。M字開脚でしゃぶりつき、ま◯こから溢れ出る愛液を吸い取る。彼女はイキそうな表情で喘ぐのだったｗお次は彼女のご奉仕タイムｗ両手でち◯こを持ち、カリを包みジュボジュボ音を出しながら吸込み吸込みしゃぶっていく。

エロ過ぎるフェラチオに勃起が止まらない。この子、おち◯こ大好きなんだなｗｗｗち◯こもま◯こも準備OKよぉ〜！挿れた途端、彼女の喘ぎはより激しくなる。画面に溢れるくらいおっぱいの接写に繰り返されるピストン運動ｗ正常位も激しかったが騎乗位はもっとすごかった。感じるままに腰を動かす彼女。遠距離中の彼氏と出来ない日々の性欲を晴らす如く、久しぶりのち◯こを味わっている。ち◯こが中でしなる！しなる！欲情される腰つきに俺は彼女の胸をかりた。とても気持ちがよかった。またしようｗ

# Warning
**if the blog is dead, this script won't work properly**

# Test Bed
**OS X Yosemite 10.10.3**
* 2.5GHz Intel Core i5 / 4G / AMD Radeon
```python
def test(x):
    print(x)
```
[Mastering Markdown](https://guides.github.com/features/mastering-markdown/)
