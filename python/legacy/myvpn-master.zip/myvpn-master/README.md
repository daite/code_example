# Vultr VPS server setting (since 2018/04/12)

# 1. change timezone 
```
dpkg-reconfigure tzdata
```

# 2. change repository
```
 vim /etc/apt/sources.list
 vim: %s/archive.ubuntu.com/ftp.daum.net/g
 ```

# 3. update & upgrade repository
```
apt-get update
apt-get upgrade
```

# 4. fix locale error 
```
locale: Cannot set LC_CTYPE to default locale: No such file or directory
locale: Cannot set LC_ALL to default locale: No such file or directory

export LANGUAGE=en_US.UTF-8
export LC_ALL=en_US.UTF-8
locale-gen en_US.UTF-8
```
# 5. add a new user
```
adduser chris
cat /etc/passwd
chris:x:1000:1000:,,,:/home/chris:/bin/bash
   ```
 
# 6. list group
```
groups chris -> chris:chris
```

# 7. append group chris to sudo
```
usermod -aG sudo chris
cat /etc/group => sudo:x:27:chris
```
# 8. modify ssh config
```
vim /etc/ssh/sshd_config
PermitRootLogin no
AllowUsers chris
systemctl restart sshd.service
systemctl status sshd.service
```

# 9. install anaconda
```
curl -O https://repo.continuum.io/archive/Anaconda3-5.1.0-Linux-x86_64.sh
sha256sum Anaconda3-5.1.0-Linux-x86_64.sh
7e6785caad25e33930bc03fac4994a434a21bc8401817b7efa28f53619fa9c29
```

# 10. install rtorrent
```
sudo apt-get install rtorrent
rtorrent /home/chris/a.torrent 
https://github.com/rakshasa/rtorrent/wiki/User-Guide
```
# 11. how to use screen command
```
1) create session : screen -S [session name]
2) list session : screen -ls
3) detach session: ctlr + a + d
4) reattach session: screen -r [session name]
5) delete session: screen -S [session name] -X quit
```
# 12. Ubuntu server 17.10 (rtorrent + flood)
* [Ubuntu server 17.10 (rtorrent + flood)](https://gist.github.com/daite/1a791cb7ba9f4b4f0e7a119ada8ef623)
