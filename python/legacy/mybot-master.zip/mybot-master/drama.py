#!/usr/bin/env python

from bs4 import BeautifulSoup as BS
from functools import partial, wraps
from urllib.parse import urljoin
from datetime import datetime
import requests
import telegram
import time
import re


TELEGRAM_TOKEN = 'mytoken'
TELEGRAM_CHAT_ID = 'myid'
bot = telegram.Bot(token=TELEGRAM_TOKEN)
send_msg = partial(bot.sendMessage, chat_id=TELEGRAM_CHAT_ID)
send_pic = partial(bot.send_photo, chat_id=TELEGRAM_CHAT_ID)

headers = {
    'User-Agent': ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5)'
                   'AppleWebKit/603.2.4 (KHTML, like Gecko) '
                   'Version/10.1.1 Safari/603.2.4')
}

day_dict = {
    '1': 'Mon',
    '2': 'Tues',
    '3': 'Wed',
    '4': 'Thurs',
    '5': 'Fri',
    '6': 'Sat',
    '7': 'Sun',
}

now = datetime.now()

def cron(func=None, **kwargs):
    '''
    %u: ISO 8601 weekday as a decimal number where 1 is Monday.
    example: 1, 2, …, 7
    '''
    if func is None:
        return partial(cron, **kwargs)
    @wraps(func)
    def wrapper(*args, **kw):
        if kwargs['interval'] == day_dict[now.strftime('%u')]:
            return func(*args, **kw)
        else:
            return
    return wrapper


def log(func=None, **kwargs):
    if func is None:
        return partial(log, **kwargs)
    @wraps(func)
    def wrapper(*args, **kw):
        date = now.strftime("%Y-%m-%d %H:%M:%S")
        with open('drama_log.txt', 'a') as f:
            _fmt = "{}|{}|{}".format(date, kwargs['msg'], func.__name__)
            f.write(_fmt + '\n')
        return func(*args, **kw)
    return wrapper


def check_episode_number(drama_title, episode_num):
    with open('data.txt') as f:
        episode_dict = eval(f.read())
        if episode_num in episode_dict[drama_title]:
            return -1
    with open('data.txt', 'w') as f:
        episode_dict[drama_title].add(episode_num)
        f.write("%s" %episode_dict)


def find_episode_number(url_fmt):
    for n in range(1, 12):
        url = url_fmt.format(n)
        r = requests.get(url, headers=headers)
        if r.status_code == 404:
            return n-1


@log(msg='logged')
@cron(interval='Tues')
def drama_signal():
    msg = ''
    url_fmt = 'https://www.ktv.jp/signal/story/{:02}.html'
    episode_num = find_episode_number(url_fmt)
    if check_episode_number('signal', str(episode_num)) == -1:
        return
    header = '【シグナル 長期未解決事件捜査班 {:02}話】\n'.format(episode_num)
    msg = msg + header
    url = url_fmt.format(episode_num)
    r = requests.get(url, headers=headers)
    soup = BS(r.content, 'lxml')
    for i in soup.find_all('div', {'class': 'txt_area'}):
        for j in i.find_all('p'):
            msg += j.text.replace(' ', '') + '\n'
    send_msg(text=msg)


@log(msg='logged')
@cron(interval='Mon')
def drama_confidenceman():
    msg = ''
    url = 'https://www.fujitv.co.jp/confidenceman_jp/story/index.html'
    r = requests.get(url, headers=headers)
    soup = BS(r.content, 'lxml')
    header = soup.find_all('dl', {'class': 'ttl'})[0].text.strip()
    episode_num = re.findall('\d+', header)[-1]
    if check_episode_number('confidence', episode_num) == -1:
        return
    msg = msg + '【コンフィデンスマンJP】' + '\n' + header + '\n'
    for i in soup.find_all('p'):
            msg += i.text.replace(' ', '') + '\n'
    send_msg(text=msg)


@log(msg='logged')
@cron(interval='Wed')
def drama_seigi():
    msg = ''
    url = 'https://www.ntv.co.jp/seigi-no-se/story/'
    r = requests.get(url, headers=headers)
    soup = BS(r.content, 'lxml')
    s_dict = {'class': 'drama-article-story-title'}
    info = [i.text for i in soup.find_all('div', s_dict)[0].find_all('span')]
    header = ' '.join(info)
    episode_num = re.findall('\d+', header)[0]
    if check_episode_number('seigi', episode_num) == -1:
        return
    msg = msg + '【正義のセ】' + '\n' + header + '\n'
    for i in soup.find_all('p'):
            msg += re.sub('[\t\n]+', '', i.text) + '\n'
    send_msg(text=msg) 


@log(msg='logged')
@cron(interval='Sat')
def drama_miss_devil():
    msg = ''
    url_fmt = 'http://www.ntv.co.jp/missdevil/story/{:02}.html'
    episode_num = find_episode_number(url_fmt)
    if check_episode_number('miss_devil', str(episode_num)) == -1:
        return
    header = '【Missデビル 人事の悪魔・椿眞子 {:02}話】\n'.format(episode_num)
    msg = msg + header
    url = url_fmt.format(episode_num)
    r = requests.get(url, headers=headers)
    soup = BS(r.content, 'lxml')
    for text in [x.text for x in soup.find_all('p')][::2][1:-1]:
            msg += text + '\n'
    send_msg(text=msg)


@log(msg='logged')
@cron(interval='Sun')
def drama_black_pean():
    msg = ''
    url = 'http://www.tbs.co.jp/blackpean_tbs/story/'
    r = requests.get(url, headers=headers)
    soup = BS(r.content, 'lxml')
    title = soup.find_all('dl')[0].find('dt').text.strip()
    description = soup.find_all('dl')[0].find('dd').text.\
                  strip('loading......\n予告動画\r\n\n')
    episode_num = re.search('\d', title).group()
    if check_episode_number('black_pean', episode_num) == -1:
        return
    msg = msg + '【ブラックペアン】' + title + '\n'
    msg += description
    send_msg(text=msg)


@log(msg='logged')
@cron(interval='Fri')
def downtown_now():
    url = 'https://www.fujitv.co.jp/DOWNTOWN_NOW/_basic/json/program_info.json'
    r = requests.get(url, headers=headers)
    json_data = r.json()
    title = json_data['title']
    air_date = json_data['startdatetime'].split('T')[0]
    story = json_data['story'].replace('<br>', '\n')
    thumbnail_url = json_data['movie_thumbnail_url']
    if air_date != now.strftime('%Y-%m-%d'):
        return
    msg = title + '\n\n' + 'ON AIR: ' + air_date + '\n\n'
    msg += story + '\n\n' + thumbnail_url
    send_msg(text=msg)


@log(msg='logged')
@cron(interval='Sat')
def music_fair():
    url = 'http://www.fujitv.co.jp/MUSICFAIR/_basic/json/program_info.json'
    r = requests.get(url, headers=headers)
    json_data = r.json()
    title = json_data['title']
    air_date = json_data['startdatetime'].split('T')[0]
    story = json_data['story'].replace('<br>', '\n')
    thumbnail_url = json_data['movie_thumbnail_url']
    if air_date != now.strftime('%Y-%m-%d'):
        return
    msg = title + '\n\n' + 'ON AIR: ' + air_date + '\n\n'
    msg += story + '\n\n' + thumbnail_url
    send_msg(text=msg)


@log(msg='logged')
@cron(interval='Wed')
def honma_deka():
    url = 'http://www.fujitv.co.jp/honma-dekka/_basic/json/program_info.json'
    r = requests.get(url, headers=headers)
    json_data = r.json()
    title = json_data['title']
    air_date = json_data['startdatetime'].split('T')[0]
    story = json_data['story'].replace('<br>', '\n')
    thumbnail_url = json_data['movie_thumbnail_url']
    if air_date != now.strftime('%Y-%m-%d'):
        return
    msg = title + '\n\n' + 'ON AIR: ' + air_date + '\n\n'
    msg += story + '\n\n' + thumbnail_url
    send_msg(text=msg)


@log(msg='logged')
@cron(interval='Sun')
def love_music():
    url = 'http://www.fujitv.co.jp/lovemusic/_basic/json/program_info.json'
    r = requests.get(url, headers=headers)
    json_data = r.json()
    title = json_data['title']
    air_date = json_data['startdatetime'].split('T')[0]
    story = json_data['story'].replace('<br>', '\n')
    thumbnail_url = json_data['movie_thumbnail_url']
    if air_date != now.strftime('%Y-%m-%d'):
        return
    msg = title + '\n\n' + 'ON AIR: ' + air_date + '\n\n'
    msg += story + '\n\n' + thumbnail_url
    send_msg(text=msg)


@log(msg='logged')
@cron(interval='Thurs')
def vs_arashi():
    url = 'http://www.fujitv.co.jp/vs_arashi/_basic/json/program_info.json'
    r = requests.get(url, headers=headers)
    json_data = r.json()
    title = json_data['title']
    air_date = json_data['startdatetime'].split('T')[0]
    story = json_data['story'].replace('<br>', '\n')
    thumbnail_url = json_data['movie_thumbnail_url']
    cast = json_data['castdetail'].replace('<br>', '\n')
    if air_date != now.strftime('%Y-%m-%d'):
        return
    msg = title + '\n\n' + 'ON AIR: ' + air_date + '\n\n'
    msg += story + '\n\n' + thumbnail_url + '\n' + cast
    send_msg(text=msg)


# --- goten
def remove_eval_error(text):
    keywords = ['true', 'false', 'null']
    for keyword in keywords:
        text = text.replace(keyword, '"%s"' %keyword)
    return text


def get_number_from_list(data_list):
    for n, title in enumerate((x['data']['title'] for x in data_list)):
        if title.startswith('次回の放送は'):
            month, day = re.search('(\d+)月(\d+)日', title).groups()
            if (int(now.month), int(now.day)) == (int(month), int(day)):
                return n
    return -1


@log(msg='logged')
@cron(interval='Tues')
def sanma_goten():
    url = 'https://www.ntv.co.jp/goten/articles.js'
    doc = requests.get(
            url, headers=headers
          ).text.split('var articles = ')[1][:-2]
    data_list = eval(remove_eval_error(doc))
    number = get_number_from_list(data_list)
    if number == -1:
        return
    episode_data = data_list[number]
    body = BS(episode_data['data']['body'], 'lxml').text
    thumbnail = urljoin(
                'https://www.ntv.co.jp/',
                episode_data['data']['thumbnail'],
                )
    send_msg(text='【踊る！さんま御殿!!】' + '\n\n' + body + thumbnail)
# --- goten


#---- 2018 summmer drama
@log(msg='logged')
@cron(interval='Wed')
def drama_takanenohana():
    msg = ''
    url = 'https://www.ntv.co.jp/takanenohana/story/'
    r = requests.get(url, headers=headers)
    soup = BS(r.content, 'lxml')
    episode_num = soup.find('span', {'class': 'number'}).text
    air_date = soup.find('span', {'class': 'date'}).text
    date = re.search(r'\d+.\d+.\d+', air_date).group()
    if date == now.strftime("%Y.%-m.%d"):
        msg += "【日本テレビ 高嶺の花 {}】 --- {}\n".format(episode_num, air_date)
        for article in soup.find_all('div', {'class': 'story-article-text'}):
            msg += article.text + '\n'
        send_msg(text=msg)
        time.sleep(0.1)
        images = soup.find_all('img', src=True)
        image_urls = (urljoin(url, image['src']) for image in images)
        for image_url in image_urls:
            send_pic(photo=image_url)
            time.sleep(0.1)
    else:
        return


@log(msg='logged')
@cron(interval='Thurs')
def drama_good_doctor():
    url = 'http://www.fujitv.co.jp/gooddoctor/_basic/json/program_info.json'
    r = requests.get(url, headers=headers)
    json_data = r.json()
    title = json_data['title']
    air_date = json_data['startdatetime'].split('T')[0]
    story = json_data['story'].replace('<br>', '\n')
    thumbnail_url = json_data['movie_thumbnail_url']
    if air_date != now.strftime('%Y-%m-%d'):
        return
    msg = title + '\n\n' + 'ON AIR: ' + air_date + '\n\n'
    msg += story + '\n\n' + thumbnail_url
    send_msg(text=msg)


if __name__ == '__main__':
    drama_good_doctor()
    drama_takanenohana()
    downtown_now()
    music_fair()
    honma_deka()
    love_music()
    vs_arashi()
    sanma_goten()
