#!/usr/bin/env python3

from urllib.parse import urljoin
from datetime import datetime
from parsel import Selector
import requests
import telegram
import time

# -- telegram setting
TELEGRAM_TOKEN = ''
TELEGRAM_USER_ID = ''

# -- editorial info & date
editorial_url = 'http://opinion.mk.co.kr/list.php?sc=30500003'
TODAY = datetime.today()

# -- http header setting
USER_AGENT = ('Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0'
              'Gecko/20100101 Firefox/47.0')
headers = {'User-Agent': USER_AGENT}


def get_content(url):
    return requests.get(url, headers=headers).content


def get_fetch_info_today_editorial(exp):
    base_exp = '//dl[@class="%s"]/dt[@class="tit"]' % exp
    doc = get_content(editorial_url).decode('euc_kr')
    response = Selector(text=doc)
    base = response.xpath(base_exp)

    url = urljoin(editorial_url, base.xpath('a/@href').extract()[0])
    title = base.xpath('a/text()').extract()[0]
    date_exp = '//dl[@class="%s"]//span[@class="date"]/text()' % exp
    pub_date = response.xpath(date_exp).extract()[0]
    today = datetime.strftime(TODAY, '%Y/%m/%d')

    ret = title, url, pub_date if today in pub_date else None
    return ret


def get_fetch_content_today_editorial(title, url, pub_date):
    doc = get_content(url).decode('euc_kr')
    response = Selector(text=doc)
    text = response.xpath('//div[@class="view_txt"]/text()').extract()[1:-1]
    text.insert(0, pub_date + '\n')
    text.insert(1, title)
    msg = ''.join(text)
    return msg


def bot_send_msg_to_user(tag):
    params = get_fetch_info_today_editorial(tag)
    if not isinstance(params, tuple):
        return
    msg = get_fetch_content_today_editorial(*params)
    bot = telegram.Bot(token=TELEGRAM_TOKEN)
    bot.sendMessage(chat_id=TELEGRAM_USER_ID, text=msg)


if __name__ == '__main__':
    bot_send_msg_to_user('article_list pt0')
    time.sleep(1)
    bot_send_msg_to_user('article_list')
