#!/usr/bin/env python3
from datetime import datetime
from scrapy import Selector
import telegram
import requests
import time
import os

AUDIO_FILE_DIR = '/home/attack/audio'
if not os.path.exists(AUDIO_FILE_DIR):
    os.mkdir(AUDIO_FILE_DIR)
bot = telegram.Bot(token='')
chat_id = ''
url = 'http://www.nhk.or.jp/r-news/podcast/nhkradionews.xml'
response = Selector(text=requests.get(url).content)
TODAY = datetime.today().strftime("%Y%m%d") + '07'
titles = response.xpath('//item/title/text()').extract()
audio_urls = response.xpath('//item/enclosure/@url').extract()
pairs = list(zip(titles, audio_urls))
filtered_pairs = [x for x in pairs if TODAY in x[1]]

if any(filtered_pairs):
    audio_file_name = filtered_pairs[0][0] + '.mp3'
    audio_file_url = filtered_pairs[0][1]
    audio_file_abspath = os.path.join(AUDIO_FILE_DIR, audio_file_name)
    with open(audio_file_abspath, 'ab') as f:
        f.write(requests.get(audio_file_url).content)
        time.sleep(2)
        bot.send_audio(chat_id=chat_id, audio=open(audio_file_abspath, 'rb'))
        os.system('rm "{}"'.format(audio_file_abspath))
