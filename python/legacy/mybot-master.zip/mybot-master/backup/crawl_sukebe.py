#!/usr/bin/env python3
import requests
from bs4 import BeautifulSoup as BS
from collections import namedtuple
from urllib.request import urljoin
import re
import http.client as http_client
import gevent
from gevent import monkey; monkey.patch_all()
import time
import json

#http_client.HTTPConnection.debuglevel = 1

file_pat = re.compile(r'[a-zA-Z0-9]+-\d+')
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6)' 
            'AppleWebKit/537.36 (KHTML, like Gecko)' 
            'Chrome/60.0.3112.113 Safari/537.36',
            'Host': 'sukebei.nyaa.si'}

contents = ['title', 'link', 'size', 'date', 
            'seeder_cnt', 'leecher_cnt', 'snatch_cnt'
           ]
jav_data = namedtuple('jav_data', contents)
total_data = []

def get_jav_information_from_url(url, page_num=1):
    '''
    :: url: ex) https://sukebei.nyaa.si/user/offkab
    '''
    url = '{}?p={}'.format(url, page_num)
    print("[*]Starting Crawling from {}".format(url))
    r = requests.get(url, headers=headers)
    soup = BS(r.content, 'lxml')
    rows = soup.find_all('tr', {'class': 'default'})
    if len(rows) == 0:
        rows = soup.find_all('tr', {'class': 'success'})
    print("Found {} data, HTTP Status: {}".format(len(rows), r.status_code))

    for row in rows:
        cols = row.find_all('td')
        # cols[1] -- title
        # cols[2] -- torrent file link
        # cols[3] -- file size
        # cols[4] -- uploaded date
        # cols[5] -- seeder cnt
        # cols[6] -- leecher cnt
        # cols[7] -- snatch_cnt
        file_name = cols[1].find_all('a', title=True)[-1]['title']
        try:
            av_movie_no = re.search(file_pat, file_name).group()
        except:
            av_movie_no = file_name

        sub_file_link = cols[2].find('a', href=True)['href']
        file_link = urljoin('https://sukebei.nyaa.si', sub_file_link)

        file_size = cols[3].text
        uploaded_date = cols[4].text
        seeder_cnt = int(cols[5].text)
        leecher_cnt = int(cols[6].text)
        snatch_cnt = int(cols[7].text)

        data = jav_data(av_movie_no, file_link, file_size, uploaded_date, 
                        seeder_cnt, leecher_cnt, snatch_cnt)
        total_data.append(data)

    print("[*]Done Crawling from {}".format(url))


def get_top10_torrent(total_data):
    '''
    :: get_top10_torrent based on seeder count
    '''
    s = sorted(total_data, key=lambda x: x.snatch_cnt)[::-1][:10]
    for n, i in enumerate(s, 1):
        print('{:02d} --> {}: ({}, {}, {})'.format(n, i.title, i.seeder_cnt, 
                i.leecher_cnt, i.snatch_cnt))


def attack(total_target_page=50, max_conn=6):
    url = 'https://sukebei.nyaa.si/user/offkab'
    for i in range(1, total_target_page, max_conn):
        start = i
        end = i + max_conn
        if end > total_target_page:
            end = total_target_page + 1
        jobs = [gevent.spawn(get_jav_information_from_url, url, no) 
                for no in range(start, end)]
        gevent.joinall(jobs, timeout=5)
        time.sleep(1)

    get_top10_torrent(total_data)


def save_data_to_file():
    for i in total_data:
        s = {'title': i.title, 'link': i.link, 
             'size': i.size, 'date': i.date, 
            'seeder_cnt': i.seeder_cnt, 
            'leecher_cnt': i.leecher_cnt, 'snatch_cnt': i.snatch_cnt}
        with open('a.json', 'a') as f:
            f.write(json.dumps(s) + '\n')


if __name__ == '__main__':
    attack()
    save_data_to_file()
    # url = 'https://sukebei.nyaa.si/user/offkab'
    # get_jav_information_from_url(url, 8)
    # #get_top10_torrent(total_data)
