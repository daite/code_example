#!/usr/bin/env python3

import telegram
import feedparser
import requests
import os

TELEGRAM_TOKEN = ''
TELEGRAM_ID = ''
FILE_SAVE_PATH = ''

if not os.path.exists(FILE_SAVE_PATH):
    os.mkdir(FILE_SAVE_PATH)

rss_url = 'https://podcasts.files.bbci.co.uk/p02nq0gn.rss'
d = feedparser.parse(rss_url)
data = d['entries'][0]
title = data['title']
mp3_url = data['links'][0]['href'].replace('download-low', 'download')
audio_file_abspath = "{}".format(os.path.join(FILE_SAVE_PATH, title + '.mp3'))

with open(audio_file_abspath, 'ab') as f:
    f.write(requests.get(mp3_url).content)

try:
    bot = telegram.Bot(token=TELEGRAM_TOKEN)
    bot.send_audio(chat_id=TELEGRAM_ID, audio=open(audio_file_abspath, 'rb'))
finally:
    os.system('rm "{}"'.format(audio_file_abspath))
