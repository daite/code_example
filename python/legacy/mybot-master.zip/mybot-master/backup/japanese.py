#!/usr/bin/env python3
import requests
from bs4 import BeautifulSoup as BS
from collections import namedtuple
import telegram

APP_ID = ''
chat_id = ''
token = ''


def get_kanji_information(sentences, level=7):
    data = set()
    info = namedtuple('kanj_info', ['kanji', 'furigana'])
    for sentence in sentences:
        rubi_url = 'https://jlp.yahooapis.jp/FuriganaService/V1/furigana'\
                   '?appid={}&grade={}&sentence={}'.\
                   format(APP_ID, level, sentence)
        r = requests.get(rubi_url)
        if r.status_code == 200:
            soup = BS(r.content, 'lxml')
            for root in soup.find_all('word'):
                try:
                    furigana = root.find('furigana').get_text()
                    surface = root.find('surface').get_text()
                    d = info(surface, furigana)
                    data.add(d)
                except AttributeError:
                    pass
        else:
            print(r.status_code)
    return data


def send_kanji_data(title, sentences):
    msg = []
    data = get_kanji_information(sentences)
    for num, d in enumerate(data, 1):
        fmt = '{:02d}. {}({})\n'.format(num, d.kanji, d.furigana)
        msg.append(fmt)
    bot = telegram.Bot(token=token)
    msg.insert(0, title)
    bot.sendMessage(chat_id=chat_id, text=''.join(msg))
