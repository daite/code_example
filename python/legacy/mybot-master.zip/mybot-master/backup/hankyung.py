#!/usr/bin/env python3
import requests
from scrapy import Selector
from datetime import datetime
import http.client as http_client
from functools import partial
import telegram

user_agent = ('Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36')
headers = {'User-Agent': user_agent}


def debug(func=None, *, option):
    if func is None:
        return partial(debug, option=option)

    def wrapper(*args, **kwargs):
        if option:
            http_client.HTTPConnection.debuglevel = 1
        return func(*args, **kwargs)
    return wrapper


@debug(option=False)
def send_msg():
    url = 'http://news.hankyung.com/opinion'
    response = Selector(text=requests.get(url, headers=headers).content)
    title_xpath = '//strong[@class="tit_list"]'
    titles = response.xpath(title_xpath)[0].xpath('//ol/li/a/text()').extract()
    link_xpath = '//strong[@class="tit_list"]'
    links = response.xpath(link_xpath)[0].xpath('//ol/li/a/@href').extract()

    update_date = datetime.strftime(datetime.now(), '%Y-%m-%d %H:%M:%S')
    msg = '[한국경제 주요뉴스: {}]\n'.format(update_date)
    msg += '~' * 40 + '\n'
    for n, (t, l) in enumerate(zip(titles, links), 1):
        _format = "{}.{}\n{}\n".format(n, t, l)
        msg += _format
    bot = telegram.Bot(token='MYTOKEN')
    bot.sendMessage(chat_id='MYID', text=msg)


if __name__ == '__main__':
    send_msg()
