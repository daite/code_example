#!/usr/bin/env python3

from scrapy import Selector
import requests
import telegram
import logging
import json
import os

# -- logging
logging.basicConfig(filename='drama.log',
                    filemode='a',
                    format='%(asctime)s %(message)s', 
                    datefmt='%m/%d/%Y %I:%M:%S %p --',
                    level=logging.DEBUG)
logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)

# -- telegram setting
TELEGRAM_TOKEN = ''
TELEGRAM_CHAT_ID = ''

# -- title, msg format
translate_title = {
    '我是命中注定的人': '僕の運命の人です',
    '逆转重生': 'Reverse',
    '贵族侦探': '貴族探偵'
}
msg_format = "[{}] {} updated!!\n url: {}"

# -- jp hp
jp_drama_url = {
    '我是命中注定的人': 'http://www.ntv.co.jp/boku-unmei/js/story_backnumber.js'
}

# -- header user-agent
headers = {
    'User-Agent': ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5)'
                   'AppleWebKit/603.2.4 (KHTML, like Gecko) '
                   'Version/10.1.1 Safari/603.2.4')
}


def get_data(url):
    _data = {}
    doc = requests.get(url, headers=headers).content
    response = Selector(text=doc)
    for div in response.xpath('//div'):
        try:
            episode = div.xpath('text()').extract()[0]
            if 'E' in episode:
                pan_url = div.xpath('a/@href').extract()[0]
                _data[episode.strip(' \xa0')] = pan_url
        except IndexError:
            pass

    return _data if any(_data) else None


def check_update(jp_title, scraped_data):
    db_file_name = '{}.json'.format(jp_title)
    if not os.path.exists(db_file_name):
        with open(db_file_name, 'w') as f:
            f.write(json.dumps({}))

    with open(db_file_name, 'r') as f:
        doc = f.read()
    db_data = json.loads(doc)

    if db_data == scraped_data:
            msg = "[{}]: No update!!".format(jp_title)
            logging.debug(msg)
    else:
        updated_keys = sorted(set(scraped_data) - set(db_data))
        for key in updated_keys:
            msg = msg_format.format(jp_title, key, scraped_data[key])
            bot = telegram.Bot(token=TELEGRAM_TOKEN)
            bot.sendMessage(chat_id=TELEGRAM_CHAT_ID, text=msg)
            logging.debug(msg)
        with open(db_file_name, 'w') as f:
            f.write(json.dumps(scraped_data))


def get_latest_episode(title):
    url = jp_drama_url[title]
    print(url)
    doc = requests.get(url, headers=headers).content
    sel = Selector(text=doc)
    return 'Homepage info : EP{:02d}'.format(len(sel.xpath('//li')))


def drama_bot():
    interesting_dramas = ['我是命中注定的人']
    for drama in interesting_dramas:
        url = 'http://www.fixsub.com/portfolio/{}'.format(drama)
        chinese_title = url.split('/')[-1]
        scraped_data = get_data(url)
        if scraped_data is None:
            msg = "[{}] No available data".format(drama)
            logging.debug(msg)
            return None
        jp_title = translate_title[chinese_title]
        check_update(jp_title, scraped_data)


if __name__ == '__main__':
    drama_bot()
