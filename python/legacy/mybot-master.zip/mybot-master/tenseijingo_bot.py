#!/usr/bin/env python3
from bs4 import BeautifulSoup as BS
from japanese import send_kanji_data
from urllib.parse import urljoin
import http.client as http_client
from datetime import datetime
from functools import wraps
import requests
import logging
import telegram
import time
import re

# -- Logger
logging.basicConfig(filename='bot.log',
                    filemode='a',
                    format='%(asctime)s %(message)s',
                    datefmt='%m/%d/%Y %I:%M:%S %p',
                    level=logging.DEBUG)
logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)

# -- TELEGRAM
TELEGRAM_TOKEN = ''

# -- Host Info
host = 'digital.asahi.com'
user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) \
              Gecko/20100101 Firefox/53.0"
payload = {
    "jumpUrl": "http://www.asahi.com/?&ref=",
    "login_id": "",
    "login_password": "",
}
headers = {
    "Host": host,
    "User-Agent": user_agent,
}

# -- global info
pat = re.compile(r"/\w+/DA[A-Z0-9]+.html")
TODAY = datetime.today()


def logged(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        logging.debug("executed " + func.__name__)
        return func(*args, **kwargs)
    return wrapper


def debug(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        http_client.HTTPConnection.debuglevel = 1
        return func(*args, **kwargs)
    return wrapper


@logged
def tenseijingo_bot():
    with requests.Session() as session:
        # -- Login
        login_url = 'https://digital.asahi.com/login/login.html'
        session.post(login_url, headers=headers, data=payload)

        # -- get tenseijingo url from main url
        main_page_url = "http://www.asahi.com/shimen/{}{:02d}{:02d}/"\
                        .format(TODAY.year, TODAY.month, TODAY.day)
        headers['Host'] = 'www.asahi.com'
        resp = session.get(main_page_url, headers=headers)
        if resp.status_code == 404:
            message = "[天声人語] No update"
        else:
            soup = BS(resp.content, "lxml")
            link = [urljoin("http://digital.asahi.com", x["href"])
                    for x in soup.findAll('a', href=True)
                    if pat.search(x["href"])][0]

            # --- get title, date, text from tenseijingo url
            headers['Host'] = 'digital.asahi.com'
            resp = session.get(link, headers=headers)
            soup = BS(resp.content, "lxml")
            title_sel = '#MainInner > div.ArticleTitle > div > h1'
            title = soup.select(title_sel)[0].text
            date_sel = '#MainInner > div.ArticleTitle > div > p.LastUpdated'
            date = soup.select(date_sel)[0].text
            text_sel = '#MainInner > div.ArticleBody > div.ArticleText > p'
            text = soup.select(text_sel)[0].text

            # -- message
            message = date + '\n' + title + '\n' + text
            bot = telegram.Bot(token=TELEGRAM_TOKEN)
            chat_id = ''
            bot.sendMessage(chat_id=chat_id, text=message)
            time.sleep(1)
            send_kanji_data("[天声人語]: " + date + "\n", message.split('\n'))


if __name__ == '__main__':
    tenseijingo_bot()
