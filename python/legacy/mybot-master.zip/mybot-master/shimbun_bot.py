#!/usr/bin/env python3
from scrapy import Selector
from japanese import send_kanji_data
from bs4 import BeautifulSoup as BS
from urllib.parse import urljoin
from functools import wraps
from datetime import datetime
import http.client as http_client
import requests
import telegram
import logging
import time
import re

logging.basicConfig(filename='bot.log',
                    filemode='a',
                    format='%(asctime)s %(message)s',
                    datefmt='%m/%d/%Y %I:%M:%S %p',
                    level=logging.DEBUG)

logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)

d = datetime.today()
TODAY = [str(d.year), str(d.month), str(d.day)]

TELEGRAM_TOKEN = ''


def debug(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        http_client.HTTPConnection.debuglevel = 1
        return func(*args, **kwargs)
    return wrapper


def logged(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        logging.debug("executed " + func.__name__)
        return func(*args, **kwargs)
    return wrapper


@logged
def get_nikkei_editorial_text(url):
    '''
    :: text  : getting editorial text from nikkei
    :: title : getting editorial title from nikkei
    :: date  : getting editorial date from nikkei (2017/4/28付)
    '''
    soup = BS(requests.get(url).content, 'lxml')
    class_tag = 'cmn-article_text a-cf JSID_key_fonttxt'
    date = soup.find('dd', {'class': 'cmnc-publish'}).get_text()
    if re.findall('\d+', date) == TODAY:
        text = [t.get_text() for t in
                soup.findAll('div', {'class': class_tag})]
        _class_name = 'cmnc-middle JSID_key_fonthln'
        title = soup.find('span', {'class': _class_name}).get_text()
        text.insert(0, " [日経] " + date)
        text.insert(1, title)
        message = '\n'.join(text)
        return message
    else:
        return "[nikkei] No editorial today"


@logged
def get_nikkei_editorial_url():
    '''
    :: getting nikkei editorial url
    '''
    url = 'http://www.nikkei.com/news/editorial'
    sel = Selector(text=requests.get(url).content)
    _path = '//h2[@class="m-articleTitle_text"]/a/@href'
    editorial_url = sel.xpath(_path).extract()[0]
    editorial_url = urljoin(url, editorial_url)
    return editorial_url


@logged
def get_asahi_editorial_text():
    '''
    :: text  : getting editorial text from asahi
    :: title : getting editorial title from asahi
    :: date  : getting editorial date from asahi (2017年4月28日（金）付)
    '''
    ASAHI_TODAY = datetime.today()
    main_page_url = "http://www.asahi.com/shimen/{}{:02d}{:02d}/"
    main_page_url = main_page_url.format(ASAHI_TODAY.year,
                                         ASAHI_TODAY.month,
                                         ASAHI_TODAY.day)
    main_sel = Selector(text=requests.get(main_page_url).content)
    url = main_sel.xpath('//ul/li/a/@href').extract()
    new_url = urljoin('http://www.asahi.com',
                      [x for x in url if 'articles' in x][1])
    sel = Selector(text=requests.get(new_url).content)
    date = sel.xpath('//p[@class="LastUpdated"]/text()').extract()[0]

    if re.findall('\d+', date)[:3] == TODAY:
        text = sel.xpath('//div[@class="ArticleText"]/p/text()').extract()
        title = sel.xpath('//div[@class="Title"]/h1/text()').extract()[0]
        text.insert(0, " [朝日] " + date)
        text.insert(1, title)
        message = '\n'.join(text)
        return message
    else:
        return "[asahi] No editorial today"


@logged
def shimbun_bot():
    '''
    :: A bot sends a parsed data based on url
    '''
    nikkei_url = get_nikkei_editorial_url()
    nikkei_text = get_nikkei_editorial_text(nikkei_url)
    asahi_text = get_asahi_editorial_text()
    bot = telegram.Bot(token=TELEGRAM_TOKEN)
    chat_id = ''

    bot.sendMessage(chat_id=chat_id, text=nikkei_text)
    nikkei_msg = nikkei_text.split('\n')
    send_kanji_data(nikkei_msg[0] + '\n', nikkei_msg)

    time.sleep(2)
    bot.sendMessage(chat_id=chat_id, text=asahi_text)
    asahi_msg = asahi_text.split('\n')
    send_kanji_data(asahi_msg[0] + '\n', asahi_text.split('\n'))


if __name__ == '__main__':
    shimbun_bot()
