#!/usr/bin/env python3

from bs4 import BeautifulSoup as BS
from functools import partial
from datetime import datetime
import requests
import telegram
import re

TELEGRAM_TOKEN = ''
TELEGRAM_CHAT_ID = ''
bot = telegram.Bot(token=TELEGRAM_TOKEN)
send_msg = partial(bot.sendMessage, chat_id=TELEGRAM_CHAT_ID)

headers = {
    'User-Agent': ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5)'
                   'AppleWebKit/603.2.4 (KHTML, like Gecko) '
                   'Version/10.1.1 Safari/603.2.4')
}

now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

drama_dict = {
    'zettai_reido': 
    [
        '絶対零度～未然犯罪潜入捜査～',
        'http://zhuixinfan.com/viewtvplay-888.html',
    ],
    'kono_sekai_no_katasumi_ni':
    [
        'この世界の片隅に',
        'http://zhuixinfan.com/viewtvplay-897.html',
    ],
    'takane_no_hana':
    [
        '高嶺の花',
        'http://zhuixinfan.com/viewtvplay-890.html',
    ],
    'good_doctor':
    [
        'グッド ドクター',
        'http://zhuixinfan.com/viewtvplay-891.html',
    ],
    'cheer_dance':
    [
        'チア☆ダン',
        'http://zhuixinfan.com/viewtvplay-895.html',
    ],
    
    'code_blue':
    [
        'コード・ブルー-もう一つの日常':
        'http://zhuixinfan.com/viewtvplay-900.html'
    ],
}

def send_msg_from_title(drama_english_title):
    data = eval(open('data.txt').read())
    data_list = drama_dict[drama_english_title]
    r = requests.get(data_list[1], headers=headers)
    soup = BS(r.content, 'lxml')
    filenames = ['.'.join(i.text.split('.')[1:])\
                for i in soup.find_all('a', href=True) \
                if 'main.php?mod' in i['href']][3:]
    for filename in filenames:
        m = re.search(r'Ep(\d+)', filename)
        if m:
            episode_number = m.group(1)
            if not episode_number  in data[drama_english_title]:
                msg = '[일드 업로드 확인 봇 : {}]\n'.format(now)
                msg += '{}\n'.format(data_list[0])
                msg += '{}화가 업로드 되었습니다.\n\n'.format(episode_number)
                msg += filename
                data[drama_english_title].add(episode_number)
                send_msg(text=msg)
                with open('data.txt', 'w') as f:
                    f.write(str(data))

if __name__ == '__main__':
    for key in drama_dict.keys():
        send_msg_from_title(key)
