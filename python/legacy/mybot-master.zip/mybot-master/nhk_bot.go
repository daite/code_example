package main

import (
	"encoding/xml"
	"fmt"
	"gopkg.in/gomail.v2"
	"io/ioutil"
	"log"
	"net/http"
	"time"
)

type Item struct {
	Title string `xml:"title"`
	Link  string `xml:"link"`
}

type Items struct {
	Item []Item `xml:"channel>item"`
}

func main() {
	resp, err := http.Get("http://www3.nhk.or.jp/rss/news/cat0.xml")
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()
	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatal(err)
	}
	var i Items
	x := xml.Unmarshal(data, &i)
	if x != nil {
		log.Fatal(err)
	}
	msg := ""
	for n, v := range i.Item {
		msg += fmt.Sprintf("%d.%s -- <a href=%s>LINK</a><br>\n", n+1, v.Title, v.Link)
	}
	t := time.Now()
	currentTime := t.Format("2006-01-02 15:04:05")
	m := gomail.NewMessage()
	m.SetHeader("From", "xxxxx@gmail.com)
	m.SetHeader("To", "xxxxx@gmail.com")
	m.SetHeader("Subject", "NHK 主要ニュース -- "+currentTime)
	m.SetBody("text/html", msg)
	d := gomail.NewPlainDialer("smtp.gmail.com", 587, "xxxxx@gmail.com", "password")
	if err := d.DialAndSend(m); err != nil {
		panic(err)
	}
}
