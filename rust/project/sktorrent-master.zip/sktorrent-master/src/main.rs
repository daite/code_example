use std::io;
use sktorrent::*;

fn main() {
    println!("Please input search item: ");
    let mut search_item = String::new();
    io::stdin()
        .read_line(&mut search_item)
        .expect("Failed to read line");

    let zipped_data = get_zipped_data(&search_item);
    print_data(zipped_data);
}
