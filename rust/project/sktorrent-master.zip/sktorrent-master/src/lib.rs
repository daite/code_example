#[macro_use] extern crate prettytable;
use prettytable::{Table, Row, Cell, format};
use std::io::Write;
use regex::Regex;
use reqwest;
use std::io;

static DEFAULT_HOST_URL: &str = "https://torrentube.to";

fn attack_server() -> String {
    let mut output = io::stdout();
    let default_url = DEFAULT_HOST_URL;
    for num in 1..100 {
        let url = format!("https://{}.torrentube.net", num);
        print!("\r{}", url);
        output.flush().unwrap();
        let resp = reqwest::blocking::get(&url);
        if let Err(_) = resp {
            continue
        } else {
            print!("\n");
            return url
        }
    }
    default_url.to_string()
}   


fn get_body(host_url: &str, search_name: &str) -> String {
    let search_url = format!("{}/kt/search?p&q={}", host_url, search_name);
    let res = reqwest::blocking::get(&search_url[..]).unwrap();
    let body = res.text().unwrap();
    body
}


fn get_titles(text: &str) -> Vec<String> { 
    let re = Regex::new(r"'fn': '(.+?)'").unwrap();    
    let mut v: Vec<String> = vec![];
    let result = re.captures_iter(text);
    for r in result {
      let data = r.get(1).unwrap();
      v.push(data.as_str().to_string());
    }
   v
}

fn get_magnets(text: &str) -> Vec<String> { 
    let magnet_prefix = "magnet:?xt=urn:btih:";
    let re = Regex::new(r"'hs': '([0-9,a-z]{40})'").unwrap();    
    let mut v: Vec<String> = vec![];
    let result = re.captures_iter(text);
    for r in result {
      let data = r.get(1).unwrap();
      v.push(format!("{}{}", magnet_prefix, data.as_str()));
    }
   v
}

pub fn get_zipped_data(search_item: &String) -> Vec<(String, String)> {
    let host_url = attack_server();
    let text = get_body(&host_url, &search_item);
    let titles = get_titles(&text);
    let magnets = get_magnets(&text);
    let zipped_data: Vec<(String, String)> = titles.into_iter()
                            .zip(magnets.into_iter())
                            .collect();
    zipped_data
}

pub fn print_data(zipped_data: Vec<(String, String)>) {
    if zipped_data.len() == 0 {
        println!("[-] ====== NO TORRENT DATA ====== ");
        return
    }
    let mut table = Table::new();
    table.set_titles(row!["Title", "Magnet"]);
    for zd in zipped_data {
        table.add_row(Row::new(vec![
             Cell::new(&zd.0),
             Cell::new(&zd.1),
        ]));
      }
      table.set_format(*format::consts::FORMAT_NO_LINESEP_WITH_TITLE);
      table.printstd();
}

#[cfg(test)]
mod tests {
    use crate::*;
    #[test]
    fn test_get_magnet_func() {
        let host_url = DEFAULT_HOST_URL;
        let search_item = "동상이몽2 너는 내운명 E149 200608";
        let text = get_body(&host_url, search_item);
        let titles = get_titles(&text);
        assert_eq!(titles, vec![
            "동상이몽2 너는 내운명.E149.200608.720p-NEXT.mp4 [안깨지는영상]",
            "동상이몽2 너는 내운명.E149.200608.720p-NEXT (안깨지는영상)",
            "동상이몽2 너는 내운명.E149.200608.720p-NEXT",
        ])
    }
    #[test]
    fn test_get_title_func() {
        let host_url = DEFAULT_HOST_URL;
        let search_item = "동상이몽2 너는 내운명 E149 200608";
        let text = get_body(&host_url, search_item);
        let magnets = get_magnets(&text);
        assert_eq!(magnets, vec![
            "magnet:?xt=urn:btih:7226f232a460e74e0a41aa355e9b005298381d3b",
            "magnet:?xt=urn:btih:a87ab1393d8f856be8fe3cc50192cadc9cc4acde",
            "magnet:?xt=urn:btih:3818bc5431b7390eaeabc1e9877384e6a80cdeda",
        ])
    }
}