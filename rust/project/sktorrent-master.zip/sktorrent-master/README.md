![example workflow name](https://github.com/daite/sktorrent/workflows/Rust/badge.svg)
# sktorrent
